﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ex_20_2t
{
    class Program
    {
        static void Main(string[] args)
        {
            MyThreadClass obj = new MyThreadClass("传送数据成功！");				//实例化对象，并传送值
            Thread t = new Thread(obj.ThreadMain);						//传送线程主方法
            t.Start();
            Console.Read();
        }
    }
    public class MyThreadClass									//定义一个类，注意，这里不是结构体
    {
        private string Msg;									//定义了一个字段data
        public MyThreadClass(string Msg)							//带参的构造函数
        {
            this.Msg = Msg;									//为字段赋值
        }
        public void ThreadMain()								//线程的主方法
        {
            Console.WriteLine("字段Msg的值是：{0}", Msg);		//输出字段data的值
        }
    }

}
