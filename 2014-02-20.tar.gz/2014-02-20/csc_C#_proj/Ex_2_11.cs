﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_10							//程序命名空间，也是项目名称，如Ex_2_10
	{
    class Program
	    {
	        static void Main(string[] args) 				//主函数，也是入口函数
	        {
	            int i = 5;
	            Console.WriteLine(-i);					//这里用于取反
	            Console.WriteLine(i-2);					//这里用于作差
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

