﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 1;
            int b = 2;
            double c = 1.2;
            double d = 5.3;
            double m = Add(c,d);
            Console.WriteLine(m);
            double n = Add(a,b);            
            Console.WriteLine(n);
            Console.Read();
        }
        static double  Add(double x, double y)
        {
            Console.WriteLine("计算双精度数");
            return x + y;
        }
        static int  Add(int x, int y)
        {
            Console.WriteLine("计算整数");
            return x + y;
        }
    }
}
