﻿using System;
using System.Text;
namespace Ex_3_1
{
    class Program
    {
        static void Main(string[] args)
        {
        int t;
        byte val = 1;
        for (t = 0; t > 0; t = t / 2)
        if ((val & t) != 0) 
            Console.Write("{0}&{1}=1 ",t,val);
        if ((val & t) == 0)
            Console.Write("{0}&{1}=0",t,val);
        Console.Read();
        }
    }
}
