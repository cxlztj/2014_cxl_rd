﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

	private void button1_Click(object sender, EventArgs e)
	{
	     this.serviceController1.MachineName = ".";		 //获取本机名称，这里用.代替
	     this.serviceController1.ServiceName = "IISAdmin";//IIS管理器服务
	     serviceController1.Stop();						 //停止服务
	}

    }
}
