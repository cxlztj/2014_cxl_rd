﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_10
{
    class Program
    {
        static void Main(string[] args)
        {
            String a;
            String b;
            String c;
            double x1;
            double x2;

            Console.WriteLine("请输入a,b,c的值：");
            a = Console.ReadLine();
            b = Console.ReadLine();
            c = Console.ReadLine();
            double a1 = double.Parse(a);
            double b1 = double.Parse(b);
            double c1 = double.Parse(c);

            if (b1 * b1 - 4 * a1 * c1 > 0)
            {
                x1 = (-b1 - Math.Sqrt(b1 * b1 - 4 * a1 * c1)) / (2 * a1);
                x2 = (-b1 + Math.Sqrt(b1 * b1 - 4 * a1 * c1)) / (2 * a1);
                Console.WriteLine("x1与X2分别等于：" + x1+"和" + x2);
                Console.Read();
            }


            else if (b1 * b1 - 4 * a1 * c1 < 0)
            {
                Console.WriteLine("错误，无解");
                Console.Read();
            }
            else
            {
                x1 = x2 = -b1 / (2 * a1);
                Console.WriteLine("两根相等，x1=x2=" + x1);
                Console.Read();
            }
        }
    }
}
