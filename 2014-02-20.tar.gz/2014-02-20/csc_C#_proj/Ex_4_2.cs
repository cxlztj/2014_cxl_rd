﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_4_2
{
    class Program
    {
        static void Main(string[] args)
        {
            myCar car = new myCar(4, 2000,20);
            car.Info();
            car.Speak();
            Console.Read();
        }
        class Car						//定义汽车类 
        {
            public int wheels;						//公有成员，轮子个数
            protected float weight;			//受保护的，表重量
            public Car(int w, float g)			//重载车类的构造函数，注意这里，后面没有分号
            {
                wheels = w;				//成员变量，车轮
                weight = g;				//成员变量，重量                
            }            
        };
        class myCar : Car
        {
            int people;								//私有成员乘客数
            public myCar(int w, float g, int p): base(w, g)		//从基类中仿造出一辆车来了
            {
                wheels = w;							//放上自己的轮子
                weight = g;							//还有一个重量
                people = p;							//这里就是乘客数量
            }
            public void Info()
            {
                Console.WriteLine("我有{0}个车轮", wheels);
                Console.WriteLine("我重{0}Kg", weight);
                Console.WriteLine("我可以乘坐{0}个人", people);
            }
            public void Speak()				//成员方法，可以看作是车的功能
            {
                Console.WriteLine("我能够加速");	//这里的功能就是加速
            }
        };
    }
}

