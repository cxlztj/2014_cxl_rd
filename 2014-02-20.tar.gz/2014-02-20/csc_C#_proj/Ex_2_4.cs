﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_4								//程序的命名空间，也是项目名称，如Ex_2_4
{
    class Program
	    {
	        static void Main(string[] args) 				//主函数，也是入口函数
	        {
	            double d = 100.5;						//定义并初始化一个双精度型变量d
            int i;								//定义了一个整数型，用于接收转换后的值
	            i = (int)d;							//进行显示转换，从double (双精度)到int(低精度)
	            Console.WriteLine(i);					//输出结果
            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

