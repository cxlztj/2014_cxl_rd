﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");		//输出Hello World
            Console.ReadLine();				//获取输入，这里是为了运行结果窗口停留

        }
    }
}
