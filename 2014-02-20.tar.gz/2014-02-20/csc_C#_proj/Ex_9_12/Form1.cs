﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult strmsg = MessageBox.Show("返回值", "标题", MessageBoxButtons.AbortRetryIgnore);
            if (strmsg.ToString().Trim() == "Abort")		//如果用户选择了终止
            {
                MessageBox.Show("终止");			//弹出终止提示信息
            }
            if (strmsg.ToString().Trim() == "Retry")		//如果用户选择了重试
            {
                MessageBox.Show("重试");			//弹出重试提示信息
            }
            if (strmsg.ToString().Trim() == "Ignore")		//如果用户选择了忽略
            {
                MessageBox.Show("忽略");			//弹出忽略提示信息
            }
        }

    }
}
