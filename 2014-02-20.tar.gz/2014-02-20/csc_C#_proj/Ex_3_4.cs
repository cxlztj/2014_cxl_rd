﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_4							//程序的命名空间，也是项目名称，如Ex_3_4
	{
	    class Program
	    {
	        static void Main(string[] args)				//主函数，也是入口函数
	        {
	            string Choice = null;					//将字符型变量Choice赋予空值
	            Console.Write("请选择：");				//输入提示信息
	            Choice = Console.ReadLine();			//将输入的值赋予Chioce变量
	            switch (Choice)						//接收选择的值
            {
	                case "a":						//如果选a
                    Console.WriteLine("开始看书");	//输出开始看书
	                    break;						//当选了a后，就会终止分支选择
	                case "b":						//如果选b
	                    Console.WriteLine("开始看电影");	//输出开始看电影
	                    break;						//当选了b后，就会终止分支选择
	                default:							//默认选项
	                    Console.WriteLine("无效输入！ ", Choice);//如果选择的不是a，也不是b
	                    break;						//退出
	            }
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}
