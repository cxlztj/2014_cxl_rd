﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.InitialDirectory = "C:\\";		//初始化盘符
            saveFileDialog1.Filter = "bmp文件(*.bmp)|*.bmp|jpg文件(*.jpg)|*.jpg";//允许的文类型
            saveFileDialog1.FilterIndex = 2;				//指定筛选索引
            saveFileDialog1.RestoreDirectory = true;		//关闭还原当前路径
            saveFileDialog1.ShowHelp = true;			//显示帮助按钮
            saveFileDialog1.Title = "保存图片";			//对话框的标题
            saveFileDialog1.FileName = "示例图片";		//默认的文件名称
            saveFileDialog1.ShowDialog();				//显示保存对话框
        }

    }
}
