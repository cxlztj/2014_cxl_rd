﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_2
{
    public class demo					//类demo
	{
	    public void outMethod()			//类demo的成员方法
	    {
	        Console.WriteLine("父类");		//输出信息
	    }
	}
	public class sun : demo				//继承自demo
	{
	    public void outMethod2()			//类sun的成员方法
	    {
	        Console.WriteLine("子类");		//输出信息
	    }
	}
}
