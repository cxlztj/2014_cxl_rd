﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            demo class1 = new demo();		//实例化demo类对象
            class1.outMethod();				//调用demo中的自定义方法
            sun class2 = new sun();			//实例化sun类对象
            class2.outMethod();				//使用sun类对象调用从基类demo中继承的自定义方法
            class2.outMethod2();			//调用sun中的自定义方法
            Console.Read();				    //获得输入焦点，为了看运行结果
        }       
    }
}
