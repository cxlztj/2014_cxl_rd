﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ex_20_3t
{
    class Program
    {
        static void Main()
        {
            Thread t = new Thread(ThreadMain);
            t.Name = "hoan";
            t.IsBackground = true;
            t.Start();
            Console.WriteLine("主线程已经结束了");
            Console.Read();
        }
        static void ThreadMain()
        {
            Console.WriteLine("线程{0}启动", Thread.CurrentThread.Name);
            Thread.Sleep(1000);
            Console.WriteLine("线程{0}完成", Thread.CurrentThread.Name);
        }
    }

}
