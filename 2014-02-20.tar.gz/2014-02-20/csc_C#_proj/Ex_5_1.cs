﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            demo d = new demo();
            d.OutMethod();
        }
    }
}
