﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ComExs_8_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 新建ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }
        private void ShowHelpInfo(object _target)
        {
            ToolStripMenuItem target = (ToolStripMenuItem)_target;
            this.statusStrip1.Items[0].Text = target.ToolTipText;
        }

        private void 打开ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 保存ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 另存为ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 退出ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 复制ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 剪切ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 粘贴ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 撤消ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 重做ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 关于ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }

        private void 联机帮助ToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            this.ShowHelpInfo(sender);
        }
    }
}