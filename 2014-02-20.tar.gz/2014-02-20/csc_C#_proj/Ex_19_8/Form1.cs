﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
namespace Ex_19_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                RegistryKey rek = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control\Update");
                rek.SetValue("UpdateMode", 0);
                MessageBox.Show("修改刷新速度成功！");
            }
            catch (Exception ey)
            {
                MessageBox.Show("程序不合适此操作系统");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                RegistryKey rek = Registry.LocalMachine.CreateSubKey(@"ControlPanel\Desktop");
                rek.SetValue("MenuShowDelay", 0);
                MessageBox.Show("修改菜单显示速度成功！");
            }
            catch (Exception ey)
            {
                MessageBox.Show("程序不合适此操作系统");
            }
        }
    }
}
