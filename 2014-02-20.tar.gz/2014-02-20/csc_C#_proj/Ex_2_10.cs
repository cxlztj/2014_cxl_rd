﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_10
{
    class Program
    {
        static void Main(string[] args)
        {
            string  sName = "hoan";
            string  sSex = "男";
            int     iAge = 23;
            Double  dHeight = 1.72;
            Console.Write("我叫：");
            Console.WriteLine(sName);
            Console.Write("性别：");
            Console.WriteLine(sSex);
            Console.Write("年龄：");
            Console.WriteLine(iAge);
            Console.Write("身高：");
            Console.WriteLine(dHeight);
            Console.Read();
        }   
    }
}
