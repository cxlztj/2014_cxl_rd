﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "C:\\";		//初始化盘符
            openFileDialog1.Filter = "bmp文件(*.bmp)|*.bmp|jpg文件(*.jpg)|*.jpg";		//可用的文件类型
            openFileDialog1.FilterIndex = 2;				//指定索引为2
            openFileDialog1.RestoreDirectory = true;		//关闭还原当前路径
            openFileDialog1.ShowHelp = true;			//显示帮助按钮
            openFileDialog1.Title = "打开图片";			//对话框标题为“打开图片”
            openFileDialog1.FileName = "示例图片";		//文件名为“示例图片”
            openFileDialog1.ShowDialog();				//显示对话框
        }

    }
}
