﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_8
{
    class Program
    {
        static void Main(string[] args)
        {
            EqualClass equalstr = "重载“=”号运算符";
            string str =equalstr;
            Console.Write(str);
            Console.Read();
        }
        class EqualClass
        {
            private string _str;

            private EqualClass(string str)
            {
                this._str = str;
            }
            public static implicit operator EqualClass(string str)
            {
                return new EqualClass(str);
            }
            public static implicit operator string(EqualClass mystr)
            {
                return mystr._str;
            }
        }
    }
}
