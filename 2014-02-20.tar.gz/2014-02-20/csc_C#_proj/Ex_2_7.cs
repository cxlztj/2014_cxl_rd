﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_7							//程序的命名空间，也是项目名称，如Ex_2_7
	{
	    class Program
	    {
	        static void Main(string[] args)			//主函数，也是入口函数
	        {
            string i = null;					//声明一个空的字符型变量i
	            string j = "10" ?? i;				//声明字符型变量j，用”??”检查它的左操作数是否为空
	            Console.WriteLine(j);				//由于”??”的左操作数据非空，所以将字符10赋给了j
	            Console.ReadLine();				//获取输入焦点，为了看运行结果
	        }
	    }
	}

