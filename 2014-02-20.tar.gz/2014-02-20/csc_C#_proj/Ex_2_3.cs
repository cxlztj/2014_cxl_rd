﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[5];				//定义一个一维数组，它有5个元素
            for (int i = 0; i < array.Length; i++)		//循环计算i的值，最大长度是数组的长度array.Length
            {
                array[i] = i + 10;
                Console.WriteLine(array[i]);			//输出i的值
            }
            Console.ReadLine();				//获取输入焦点，为了看运行结果，放在循环体之外
        }
    }
}
