﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_5								//程序的命名空间，也是项目名称，如Ex_3_5
	{
	    class Program
	    {
	        static void Main(string[] args)				//主函数，也是入口函数
        {
	            int i = 1;							//定义一个用于循环计数的变量
	            while (i < 5)							//当i小于5的时候就执行13至16行中的代码
	            {
	                Console.WriteLine("循环了{0}次", i);	//输出循环次数
                i++;							//每执行一次，i自增1
	            }
            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

