﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_8_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btn_Click(object sender, EventArgs e)				//为加法按钮添加事件
        {
            double c;											//定义一个双精度型变量
            c = Convert.ToDouble(txtA.Text) + Convert.ToDouble(txtB.Text);	//进行类型转换后相加
            txtC.Text = Convert.ToString(c);							//转换成字符型后赋值
        }
        private void button1_Click(object sender, EventArgs e)			//为减法按钮添加事件
        {
            double c;
            c = Convert.ToDouble(txtA.Text) - Convert.ToDouble(txtB.Text);	//进行类型转换后相减
            txtC.Text = Convert.ToString(c);
        }
        private void button2_Click(object sender, EventArgs e)			//为乘法按钮添加事件
        {
            double c;
            c = Convert.ToDouble(txtA.Text) * Convert.ToDouble(txtB.Text);	//进行类型转换后相乘
            txtC.Text = Convert.ToString(c);
        }
        private void button3_Click(object sender, EventArgs e)			//为除法按钮添加事件
        {
            double c;
            c = Convert.ToDouble(txtA.Text) / Convert.ToDouble(txtB.Text);	//进行类型转换后相除
            txtC.Text = Convert.ToString(c);
        }
    }
}
