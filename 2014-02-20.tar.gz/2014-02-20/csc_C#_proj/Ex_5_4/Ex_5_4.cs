﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_4
{
    interface ImyInterface							//定义接口
    {
        string STR									//接口中的属性
        {
            get;
            set;
        }
        void outMethod();							//接口中的方法
    }
    class InheritInterface:ImyInterface				 //从接口派生的类
    {
        string str = "21天学C#";					//定义并初始化字符串,域
        public string STR							//重新实现接口中的属性
        {
            get									    //get访问器读数据
            {
                return str;							//返回值
            }
            set									    //set访问器写数据
            {
                str = value;							//写入值
            }
        }
        public void outMethod()						//实现接口中的方法
        {
            Console.WriteLine(this.STR);				//输出
        }
    }
    class Program
    {
        static void Main(string[] args)					//主程序，入口函数
        {
            InheritInterface IInterface = new InheritInterface();//实例化类对象
            IInterface.outMethod();						//调用类中方法
            Console.Read();							//获得输入焦点，这里用来让DOS窗口停留
        }
    }
}
