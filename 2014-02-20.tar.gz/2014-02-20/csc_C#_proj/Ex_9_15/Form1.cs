﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

	namespace Ex_9_15
	{
	    public partial class Form1 : Form			//窗口类
	    {
	        public Form1()							//构造函数
	        {
	            InitializeComponent();				//完成初始化工作
	        }
	        private void button1_Click(object sender, EventArgs e)	
										//按钮单击事件
	        {
	            if (textBox1.Text == "admin" && textBox2.Text == "admin")
												//判断
	            {
	                Form2 f2 = new Form2();			//创建一个窗口对象
	                f2.Show();						//调用Show()方法显示窗口
	            }
	            else
	            {
	                MessageBox.Show("账号或密码有误！");	//弹出错误提示窗口
	            }
	        }
	    }
	}

