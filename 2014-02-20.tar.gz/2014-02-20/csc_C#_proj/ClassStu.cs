﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_6
{
    class ClassStu
    {
        string  sName;
        string  sSex;
        long    iSoure;
        public ClassStu(string Name, string Sex,long Soure)
        {
            sName = Name;
            sSex = Sex;
            iSoure = Soure;
        }
        public void fnShow()
        {
            Console.WriteLine(sName);
            Console.WriteLine(sSex);
            Console.WriteLine(iSoure);
        }
        public void fnRead()
        {
            Console.WriteLine("读书");
        }
        public void fnWork()
        {
            Console.WriteLine("做作业");
        }
        ~ClassStu()
        {
        }
    } 
}
