﻿	using System;
	using System.Collections.Generic;
	using System.Text;
	using System.Xml;
	namespace LoadAndSave
	{
	    class Program
	        { 
	               static void Main(string[] args) 
	               {
	                     XmlDocument xdoc = new XmlDocument();	//声明一个XmlDocument对象
	                     xdoc.Load("book.xml");				//从指定的流加载XML文档
	                    Show(xdoc);						//在控制台中显示Xml文档的结果
	               }
	               static void Show(XmlDocument xdoc)
	               {
	                    Console.Write(xdoc.OuterXml);
                        Console.Read();
	               }
	       }
	}

