﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_3									//项目命名空间
	{
	    class Class1									//声明类Class1
	    {
	        public static string Country()					//静态方法的声明
	        {
            string strCountry = "静态方法调用";			//为字符串赋值
            return strCountry;							//返回字符串
	        }
	    }
	    class Class2									//声明类Class2
	    {
	        static void Main(string[] args)					//主函数
        {
	            Console.WriteLine(Class1.Country().ToString());	//静态方法的调用
	            Console.Read();							//获得输入焦点
        }
	    }
	}
