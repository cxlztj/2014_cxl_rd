﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Ex_19_2t
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (Directory.Exists(textBox1.Text))				//判文件夹是否存在
                {
                    label1.Text = "该文件夹已经存在";
                    return;
                }
                else
                {
                    DirectoryInfo dirinfo = System.IO.Directory.CreateDirectory(textBox1.Text);
                    label1.Text = "创成功,创建时间为：" + Directory.GetCreationTime(textBox1.Text);
                }
            }
            catch (Exception ee)
            {
                label1.Text = "处理失败！ 失败的原因是：" + ee.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(textBox1.Text))			//判断文件夹是否存在
                {
                    label1.Text = "该文件夹不存在";
                }
                else
                {
                    Directory.Delete(textBox1.Text);			//删除文件夹                    
                    label1.Text = "删除文件夹成功！";
                }
            }
            catch (Exception ee)
            {
                label1.Text = "操作失败！ 失败的原因是：" + ee.ToString();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(textBox1.Text))			//判断源文件夹是否存在
                {
                    label1.Text = "源文件夹不存在！";
                    return;
                }
                if (Directory.Exists(textBox2.Text))			//判断目标文件夹是否存在
                {
                    label1.Text = "目标文件夹已经存在！";			//输出提示信息
                    return;
                }
                Directory.Move(textBox1.Text, textBox2.Text);		//移动文件夹
                label1.Text = "文件夹移动成功！源文件已经被移除。目标文件夹为" + textBox2.Text;
            }
            catch (Exception ee)
            {
                label1.Text = "操作失败！ 失败原因：" + ee.ToString();
            }

        }
    }
}
