﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_5_7
{
    class Program
    {
        static void Main(string[] args)
        {
            demoClass a = new demoClass();
            a.Show();
            demoClass b = new demoClass(100, 200); // 用构造函数初始化对象
            b.Show();
            Console.Read();
        }
        class demoClass
        {
            public double x, y;
            public demoClass()
            {
                this.x = 0;
                this.y = 0;
            }
            public demoClass(double x, double y)
            {
                this.x = x;
                this.y = y;
            }
            public void Show()
            {
                Console.WriteLine("x={0}", x);
                Console.WriteLine("y={0}",y);
            }
        }
    }
}
