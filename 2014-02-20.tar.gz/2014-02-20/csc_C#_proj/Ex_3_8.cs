﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_8								//程序的命名空间，也是项目名称，如Ex_3_8
	{
	    class Program
	    {
	        static void Main(string[] args)				//主函数，也是入口函数
	        {
	            for (int i = 1; i <= 100; i++)				//定义一个用于循环计数的变量和循环
	            {
	                if (i == 10)						//循环体在i=10时才会退出
	                {
	                    break;						//如果i等于是10就退出
	                }
	                Console.WriteLine(i);				//输出i的值
	            }
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
        }
	    }
	}

