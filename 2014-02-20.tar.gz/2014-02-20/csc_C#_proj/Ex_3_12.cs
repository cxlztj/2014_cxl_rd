﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_12
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i <= 10; i++)
            {
                if (i == 7)
                goto lab;
            }
            lab:
                Console.WriteLine("嘿嘿，我跳出循环体了。");
            Console.ReadLine();
        }
    }
}
