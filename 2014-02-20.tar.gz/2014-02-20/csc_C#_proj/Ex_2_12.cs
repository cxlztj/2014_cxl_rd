﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 3;
            int b = 5;
            string msg =(a>b)?"3大于5":"3小于5";
            Console.Write(msg);
            Console.Read();
        }
    }
}
