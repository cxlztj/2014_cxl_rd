﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_4_7
{
    class Program
    {
        public class BaseClass
        {
            public static int x = 100;
            public static int y = 200;
        }
        public class MyClass : BaseClass
        {
            public static int x = 500; //
            public static void Main()
            {               
                Console.WriteLine("输出继承类中的X={0}",MyClass.x); // 打印x: 
                Console.WriteLine("输出基类中的X={0}",BaseClass.x);//访问隐藏基类的 x: 
                Console.WriteLine("输出继承来的Y={0}",MyClass.y);//打印不隐藏的y: 
                Console.Read();
            }
        }
    }
}
