﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Ex_9_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Maximum = 10;//设置最大长度值 
            progressBar1.Minimum = 1;
            progressBar1.Value = 1;//设置当前值 
            for (int i = 1; i <= 10; i++)//循环 
            {
                Thread.Sleep(1000);//暂停1秒 
                progressBar1.Value = i;//让进度条增加一次 
            }
        }
    }
}
