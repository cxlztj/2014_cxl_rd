﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
namespace LoadAndSave
{
    class Program
    {
        static void Main(string[] args)
        {
            //声明一个 XmlDocument 对象。
            XmlDocument xdoc = new XmlDocument();
            //从指定的流加载 XML	文档。
            xdoc.Load("XMLFile1.xml");
            //在控制台中显示 Xml 文档的结果。
            DisplayResult(xdoc);
        }
        static void DisplayResult(XmlDocument xdoc)
        {
            Console.WriteLine(xdoc.OuterXml);
            Console.Read();
        }
    }
}

