﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_6								//程序的命名空间，也是项目名称，如Ex_2_6
	{
	    class Program
	    {
	        static void Main(string[] args) 				//主函数，也是入口函数
	        {
	            Console.WriteLine(10 + 10);				//这里的”+”号作为计算数值用的
	            Console.WriteLine("10" + "10");			//这里的”+”号作为字符串相加用的
	            Console.ReadLine();					//获取输入，为了控制台窗口停下来，看输出结果
	        }
    }
	}

