﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("选项1");				//为列表框添加选项
            listBox1.Items.Add("选项2");				//为列表框添加选项
            listBox1.Items.Add("选项3"); 				//为列表框添加选项
            listBox1.Items.Add("选项4");				//为列表框添加选项
            listBox1.Items.Add("选项5");				//为列表框添加选项
            listBox1.Items.Add("选项6");				//为列表框添加选项
        }



        private void button1_Click(object sender, EventArgs e)
        {
            string strTemp = listBox1.SelectedItem.ToString();	//将左边选择的值赋给临时变量
            listBox2.Items.Add(strTemp);					//将临时变量中的值添加到右边列表框
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string strTemp = listBox2.SelectedItem.ToString();	//将右边选择的值赋给临时变量
            listBox1.Items.Add(strTemp);					//将临时变量中的值添加到左边列表框
        }
    }
}
