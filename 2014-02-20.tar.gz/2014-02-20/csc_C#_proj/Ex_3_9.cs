﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_9								//程序的命名空间，也是项目名称，如Ex_3_9
	{
	    class Program
	    {
        static void Main(string[] args)				//主函数，也是入口函数
	        {
	            for (int i = 1; i <= 10; i++)				//循环
	            {
                if (i < 6)							//如果i小于6，执行13行
	                {
	                    continue;					//注意，当i大于或者等于了6，才执行第17行
                }
	                Console.WriteLine(i);				//输出i
	            }
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

