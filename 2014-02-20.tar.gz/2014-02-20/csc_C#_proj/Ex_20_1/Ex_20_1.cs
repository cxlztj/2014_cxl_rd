﻿using System;
using System.Threading;
namespace Ex_20_1
{
    class Program
    {
        static void Main()
        {
            Thread t1 = new Thread(ThreadMain);
            t1.Start();
            Console.WriteLine("线程1");
            Console.Read();
        }
        static void ThreadMain()
        {
            Console.WriteLine("线程2");
        }
    }
}

