﻿using System;								//包含基本类和基类
using System.Collections.Generic;				//定义泛型集合的接口和类
using System.Text;							//包含用于字符编码等功能的对象
namespace Ex_5_9
{
    delegate void MyDelegate(string s);
    class MyClass
    {
        public static void Hello(string s) 			//Hello方法
        {
            Console.WriteLine("您好, {0}!", s);
        }
        public static void Goodbye(string s) 		//Goodbye方法
        {
            Console.WriteLine("再见, {0}!", s);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyDelegate a, b, c, d;
            a = MyClass.Hello;				//创建引用Hello方法
            Console.WriteLine("调用委托变量 a:");
            a("a");							//委托对象 a 
            b = MyClass.Goodbye;				// 创建引用 Goodbye 方法的
            Console.WriteLine("调用委托变量 b:");
            b("b"); 							// 委托对象 b 
            c = a + b;						// a 和 b 两个委托合成 c，
            Console.WriteLine("调用委托变量 c:");
            c("c=a+b");						// c将按顺序调用两个方法
            d = c - a;						//从组合委托c中移除 a，只留下b，用d代表移除结果
            Console.WriteLine("调用委托变量 d:");
            d("d=c-a");						// 后者仅调用Goodbye方法：
            Console.Read();
        }
    }
}
