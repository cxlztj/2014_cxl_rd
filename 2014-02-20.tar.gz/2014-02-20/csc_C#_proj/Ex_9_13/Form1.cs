﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult strmsg = MessageBox.Show("返回值", "标题", MessageBoxButtons.OKCancel);
            if (strmsg.ToString().Trim() == "OK")		//如果用户选择确定
            {
                MessageBox.Show("确定");			//弹出确定信息框
            }
            if (strmsg.ToString().Trim() == "Cancel")	//如果用户选择取消
            {
                MessageBox.Show("取消");			//弹出取消信息框
            }
        }

    }
}
