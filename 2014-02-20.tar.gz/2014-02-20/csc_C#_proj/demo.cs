﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_1
{
    class demo
    {
        public void OutMethod()					//输出
        {
            Console.WriteLine("21天学C#");		//输出信息
            Console.Read();
        }
    } 
}