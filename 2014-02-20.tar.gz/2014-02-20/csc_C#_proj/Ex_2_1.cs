﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 50;							//定义a班,有50个同学
	        int b = 40;							//定义b班,有40个同学
	        Console.WriteLine(a+b);				//输出
	        Console.ReadLine();					//加上这行才能看到运行结果，否则一闪而过
        }
    }
}
