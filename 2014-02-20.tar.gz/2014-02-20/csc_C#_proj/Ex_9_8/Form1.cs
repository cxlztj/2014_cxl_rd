﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                string strPath = Application.StartupPath.Substring(0, Application.StartupPath.Substring(0,Application.StartupPath.LastIndexOf("\\")).LastIndexOf("\\"));
											//获取路径，不包括文件名称
	    strPath += @"\help.html";				//路径加上文件
	    helpProvider1.HelpNamespace = strPath;	//将路径赋给控件
	    helpProvider1.SetShowHelp(this,true);	//设置为可见
	    this.HelpButton = true;				//显示帮助按钮
	    this.MaximizeBox = false;				//显示最大化按钮
    this.MinimizeBox = false;				//显示最小化按钮

        }
    }
}
