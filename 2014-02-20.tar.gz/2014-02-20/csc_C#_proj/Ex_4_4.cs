﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_4									//项目的命名空间
	{
	    class Class1									//声明类Class1
	    {
	        public string Country()							//非静态方法的声明
	        {
            string strCountry = "非静态方法的示例!";		//为字符串变量赋值
	            return strCountry;							//返回字符串
	        }
	        public string stradd()							//非静态方法的声明
	        {
	            Class2 class2 = new Class2();				//创建对象
	            string strField = class2.Cc() + this.Country();		//调用Class2中的方法
	            return strField;							//返回字符串
	        }
	    }
	    class Class2									//声明类Class2
	    {
	        public string Cc()								//非静态方法的声明
	        {
	            string strCc = "这是一个";					//为字符串赋值
	            return strCc;								//返回字符串
	        }
        static void Main(string[] args)					//主函数，也是程序的入口
	        {
	            Class1 class1 = new Class1();				//创建一个Class1类的对象class1
	            Console.WriteLine(class1.stradd());			//非静态方法的调用
	            Console.Read();							//获得输入焦点，看程序结果
	        }
	    }
	}

