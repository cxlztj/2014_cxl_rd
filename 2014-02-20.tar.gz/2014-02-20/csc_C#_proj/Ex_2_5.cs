﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_5								//程序的命名空间，也是项目名称，如Ex_2_5
	{
    class Program
	    {
	        static void Main(string[] args) 				//主函数，也是入口函数
	        {
            Program data = new Program();
	            data.fnTest1();						//输出fnTest1()中的i
	            data.fnTest2();						//输出fnTest2()中的i
            Console.ReadLine();					//获取输入焦点，为了看运行结果
        }
	        public void fnTest1()						//公有函数fnTest1()
	        {
	            int i;								//局部变量，它的作用范围只在fnTest1()中
	            i = 100;								//必须先赋值才能使用
	            Console.WriteLine(i);					//输出fnTest1中的i
	        }
	        public void fnTest2()						//公有函数fnTest2()
	        {
	            int i;								//此处的i作用范围只在fnTest2()中
	            i=200;								//必须先赋值才能使用
	            Console.WriteLine(i);					//输出fnTest2中的i
	        }
	    }
	}

