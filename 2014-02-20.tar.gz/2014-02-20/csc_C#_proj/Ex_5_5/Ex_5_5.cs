﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_5
{
    class Program
    {
        static void Main(string[] args)
        {
            MinHoan hoan = new MinHoan();
            hoan.MyInfo();
            hoan.Show();
            Console.Read();
        }
        public abstract class MaxHoan
        {
            public abstract void MyInfo();//请注意，这里的方法没有方法体
        }

        public class MinHoan : MaxHoan
        {
            public override void MyInfo()
            {
                Console.WriteLine("嘿，我是hoan");
            }
            public void Show()
            {
                Console.Write("OK");
            }
        }
    }
}
