﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_4_6
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassStu stu = new ClassStu("周红安","男",200511070010);
            stu.fnShow();
            stu.fnRead();
            stu.fnWork();
            Console.Read();
        }
    }
}
