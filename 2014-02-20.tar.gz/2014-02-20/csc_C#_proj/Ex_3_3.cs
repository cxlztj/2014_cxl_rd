﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_3								//程序的命名空间，也是项目名称，如Ex_3_3
	{
	    class Program
	    {
	        static void Main(string[] args)				//主函数，也是入口函数
	        {
	            bool flag = true;						//为了下面的判断，在这里先设置一个标志
	            if (flag = true)						//判断为真
            {
	                Console.WriteLine("标志位为真");		//输出
	            }
            else								//否则的话，既是假
	            {
	                Console.WriteLine("标志位为假");		//输出
	            }
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

