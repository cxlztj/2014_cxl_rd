﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            TreeNode newNode1 = treeView1.Nodes.Add("公司部门");		//添加父节点
            TreeNode newNode2 = treeView1.Nodes.Add("学校部门");		//添加父节点
            newNode1.Nodes.Add("商务部");						//为父节点1添加子节点
            newNode1.Nodes.Add("技术部");
            newNode1.Nodes.Add("市场部");
            newNode2.Nodes.Add("组织部");						//为父节点2添加子节点
            newNode2.Nodes.Add("科研处");
            newNode2.Nodes.Add("教务处");
            treeView1.ShowLines = true;							//节点间显示连线
            treeView1.ShowPlusMinus = true;						//显示加减号
            treeView1.ExpandAll();								//全部展开
        }
    }
}
