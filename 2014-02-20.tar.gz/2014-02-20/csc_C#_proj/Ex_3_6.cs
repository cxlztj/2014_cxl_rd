﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_6								//程序的命名空间，也是项目名称，如Ex_3_6
	{
	    class Program
	    {
	        static void Main(string[] args)				//主函数，也是入口函数
	        {
	            int i = 1;							//定义一个用于循环计数的变量
            do								//开始循环
	            {
	                Console.WriteLine("循环了{0}次", i);	//输出循环次数
	                i++;							//每执行一次，i自增1
	            }
              while (i < 5);						//这里是先执行了14至15行中的代码一次再判断
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

