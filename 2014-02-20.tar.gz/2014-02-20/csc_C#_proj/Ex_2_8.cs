﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_8								//程序的命名空间，也是项目名称，如Ex_2_8
	{
	    class Program
    {
	        static void Main(string[] args) 				//主函数，也是入口函数
	        {
	            Console.WriteLine(typeof(int));			//获取int型的原型
	            Console.WriteLine(typeof(System.Int32));	//也可以看作int的原型
	            Console.WriteLine(typeof(string)); 		//获取string型的原型
	            Console.ReadLine();					//获取输入焦点，为了看运行结果
	        }
	    }
	}

