﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_2_2								//程序的命名空间，也是项目名称，如Ex_2_2
{
    class Program
    {
        static void Main(string[] args) 				//主函数，也是入口函数
        {
            demo n1 = new demo();				//将引用类型demo实例化
            n1.a = 10;							//为成员a赋值
	            n1.b = 15;
	            demo n2 = n1;						//只是赋值指针,将指针指向n1.a。注意这里是关键
	            Console.WriteLine(n2.a);				//输出结果，其值实际上还是ni存储单元中的
	            Console.WriteLine(n2.b);				//输出结果，是ni中的成员b的值
	            Console.Read();						//获取输入焦点，为了看运行结果
        }
	        class demo								//引用类型的声明
	        { 
            public int a;							//成员变量
	            public int b;							//成员变量
	        }
	    }
	}

