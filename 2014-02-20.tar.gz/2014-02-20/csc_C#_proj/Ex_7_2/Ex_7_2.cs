﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace codemo
{
    class Program
    {
        static void Main(string[] args)						//主函数，程序的入口处
        {
            try										//可能存在异常，使用try块
            {
                string str = null;							//定义一个空字符串型变量
                if (str == null)								//条件判断
                {
                    throw new ArgumentException();			//抛出信息
                }
            }
            catch (ArgumentException e)						//第一个捕获异常的块
            {
                Console.WriteLine("{0}第一个异常", e.Message);	//输出信息
            }
            catch (Exception e)							//此处不会被执行
            {
                Console.WriteLine("{0}第二个异常", e.Message);	//输出信息
            }
            Console.Read();								//获取输入焦点，看运行结果
        }
    }
}
