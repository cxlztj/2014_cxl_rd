﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_3_11
{
    class Program
    {
        public static void Main()
        {
            for (int i = 1; i <= 9; i++)
            {

                Console.Write("{0}\t", i);
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(" {0}\t", i * j);
                }
                Console.WriteLine();                
            }
            Console.Read();
        } 
    }
}
