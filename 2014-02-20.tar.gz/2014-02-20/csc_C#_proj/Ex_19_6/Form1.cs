﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Ex_19_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                RegistryKey rsg = null;
                rsg = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft", true); 	//true表示可以修改
                if (rsg.GetValue("HoanReg") != null) 								//读取失败返回null
                {
                    this.textBox1.Text = rsg.GetValue("HoanReg").ToString();
                }
                else
                    this.label1.Text = "该键不存在！";
                rsg.Close();
            }
            catch (Exception ex)
            {
                this.label1.Text = ex.Message;
            }

        }
    }
}
