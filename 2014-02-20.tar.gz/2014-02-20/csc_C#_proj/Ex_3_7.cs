﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_7								//程序的命名空间，也是项目名称，如Ex_3_7
{
    class Program
    {
        static void Main(string[] args)				//主函数，也是入口函数
        {
            for (int i = 1; i < 10; i++)						//定义一个用于循环计数的变量和循环
            {
                Console.WriteLine("循环了{0}次", i);	//输出循环次数
            }
            int m = 4;
            int n = 6;
            Console.Write(n);
            Console.ReadLine();					//获取输入焦点，为了看运行结果
        }
    }
}

