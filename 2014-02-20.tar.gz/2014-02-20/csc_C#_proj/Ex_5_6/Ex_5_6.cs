﻿	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	namespace codemo
	{
	    delegate void Writer(string s);
    class Program
    {
        static void NamedMethod(string k)		//委托所调用的命名方法:
	        {
	            System.Console.WriteLine(k);		//输出接收的参数信息
	        }
        static void Main(string[] args)			//主函数，入口函数
       {
	            Writer w = delegate(string j) 		//委托类调用匿名方法:
	            {
	                System.Console.WriteLine(j);		//输出
	            };
	            w("调用了匿名方法。");			//调用匿名方法
            Console.WriteLine();				//输出
	            w = new Writer(NamedMethod);		//创建对象
	            w("调用了命名方法。");			//调用命名方法
	            Console.Read();					//获取输入焦点，看运行结果
	        }
	    }
	}

