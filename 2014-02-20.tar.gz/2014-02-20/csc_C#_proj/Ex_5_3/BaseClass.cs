﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_3
{
    public class MyInterest
    {
        public virtual void Interest()
        {
            Console.WriteLine("我的爱好");
            Console.Read();
        }
    }
    public class Write : MyInterest
    {
        public override void Interest()
        {
            Console.WriteLine("写作");
        }
    }
    public class toProgram :MyInterest
    {
        public override void Interest()
        {
            Console.WriteLine("编程");
        }
    }
    public class Sing :MyInterest
    {
        public override void Interest()
        {
            Console.WriteLine("唱歌");
        }
    }
}
