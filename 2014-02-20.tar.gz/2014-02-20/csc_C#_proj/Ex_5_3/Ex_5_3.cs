﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_3
{
    class Program
    {
        public static int Main(string[] args)
        {
            MyInterest[] dObj = new MyInterest[4];
            dObj[0] = new Write();
            dObj[1] = new toProgram();
            dObj[2] = new Sing();
            dObj[3] = new MyInterest();
            foreach (MyInterest Obj in dObj)
            {
                Obj.Interest();
            }
            return 0;            
        } 

    }
}
