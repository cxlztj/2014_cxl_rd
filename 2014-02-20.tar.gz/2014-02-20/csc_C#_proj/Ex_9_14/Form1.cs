﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex_9_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult strmsg = MessageBox.Show("返回值",					//提示信息
                                                "标题",						//窗口标题
                                                 MessageBoxButtons.OKCancel,	//显示确定按钮
                                                 MessageBoxIcon.Information);	//显示叹号图标
        }

    }
}
