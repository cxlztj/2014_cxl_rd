﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Ex_5_8
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass inter = new MyClass();
            inter.fnShow();
            Console.ReadLine(); 
        }        
        public interface DemoInter        //定义接口     
        {
            void fnShow();         //定义方法，无返回值
        }
        public class MyClass : DemoInter   //MyClass实现DemoInter接口的功能
        {
            public void fnShow()  //方法的实现
            {
                Console.WriteLine("实现了接口的功能!");
            }
        }
    }
}
