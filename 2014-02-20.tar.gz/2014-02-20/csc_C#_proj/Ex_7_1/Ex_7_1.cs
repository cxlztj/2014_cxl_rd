﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace codemo
{
    class Program
    {
        static void Main(string[] args)			//主函数，程序的入口处
        {
            int i = 1;							//定义整型变量i并赋值1
            string s = "hello";					//字符串型变量s，并赋值hello
            object o = s;						//类型转换
            try							//可能存在异常，使用try块
            {
                i = (int)o;					//类型强制转换,
            }
            catch							//捕获异常块
            {
                //这里就是捕获异常的代码
            }
            finally							//在这个块中释放资源
            {
                Console.WriteLine("i={0}", i);		//正常的输出
            }
            Console.Read();					//获取输入焦点，看运行结果

        }
    }
}
