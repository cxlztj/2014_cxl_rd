﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace Ex_2_9
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList ayyaylist = new ArrayList();
            for (int i = 0; i < 10; i++)
            {
                ayyaylist.Add(i);               //这里就是装箱
            }
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(ayyaylist[i]);
            }
            Console.Read();
        }
    }
}
