﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex_3_2									//命名空间，也是项目名称，如Ex_3_1
	{
    class Program
	    {
	        static void Main(string[] args)					//主函数，也是入口函数
	        {
            int a, b;									//定义两个整数a和b
            Boolean flag	;							//定义布尔型变量 用于接收结果的真和假
	        input:										//这是一个标号，规定的程序段的名称
            {
	                Console.WriteLine("请输入数A：");		//输出提示
	                a = Convert.ToInt32(Console.ReadLine());	//输入一个数，转换为整数后赋予a
	                Console.WriteLine("请输入数B：");		//输出提示
	                b = Convert.ToInt32(Console.ReadLine());	//输入一个数，转换为整数后赋予b
                if (a > b)							//如果a>b，执行18～21行
                {
	                    Console.WriteLine("A>B");			//输出：A>B
	                    flag = true;						//将flag标志置为true
                        Console.Read();
	                }
	                else								//如果a<b或者a=b，执行23～26行
	                {
	                    Console.WriteLine("A<B");			//输出：A<B
                        flag = false;						//将flag标志置为false
                        Console.Read();
	                }
	            }
	            if (flag == false)							//如果flag标志是falsr,执行30行
            { 
	                goto input;							//跳转到input标号处，本例的11行处
	            }
	        }
	    }
	}

